
BasicGame.MainMenu = function (game) {

	this.music = null;
	this.playButton = null;

};

BasicGame.MainMenu.prototype = {
  init: function (score) {
    this.score = score;
  },

	create: function () {
	},

	update: function () {
	},

	startGame: function (pointer) {
	}
};
